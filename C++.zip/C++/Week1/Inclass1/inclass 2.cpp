#include <iostream>

long const sDay = 86,400;
long const sHr = 3600;
long const Smn = 60;

long days, hrs, mins, secs, totSeconds, SecRemaining;

using namespace std;

int main()
{
  cout << "Enter in the number of seconds:";
  cin >> totSeconds;
  
  days = totSeconds / sDay;
  SecRemaining = totSeconds % sDay;
  hrs = SecRemaining / sHr;
  SecRemaining = SecRemaining % sHr;
  
  cout << "days:"; << endl;
  cout << SecRemaining;
  return 0;
}
