#include <instream>

using namespace std;

int htIn;                                //height in inches
int const inFt = 12                      //conversion factor
int ft, in;                              //valuse in feet and inches
using namespace std;
int main(int argc, char *argv[])
{
	cout << "Enter total inches:" ;
	cin >> htIn;
	
	cout << endl << endl;
	
	cout << htIn << "Height in inches = ";
	
	ft = htIn / inFt;
	in = htIn % inFt;
	
	cout << ft << " feet, " << in << " inches." << endl;
	
	return 0;
	
	
}
