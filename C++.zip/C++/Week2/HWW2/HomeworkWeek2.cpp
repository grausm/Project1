#include <iostream>

using namespace std;

const float mP100k = 62.14;
const float lPG = 3.875;

int main() {   
    
	cout << "How many liters per kilometer?: ";
	double lP100km;
	cin >> lP100km;
	
	double mpg = 1 / (lP100km / lPG) * mP100k;
    cout << lP100km
        << " Litters per 100 Kilometers is: "
	    << mpg
	    << " Miles per gallon"
	    << endl;
    
    cin.clear();                               
    cin.ignore(1000,'\n');                     
    cin.get();
	return (0);
}
