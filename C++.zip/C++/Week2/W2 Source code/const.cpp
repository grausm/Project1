//const1.cpp
//Example of using Global Const

#include<iostream>

double const SALES_TAX = .06;

using namespace std;

int main()
{
    cout << "The sales tax on $100 is: " << (100 * SALES_TAX) << endl;
    
    cin.clear();                               
    cin.ignore(1000,'\n');                     
    cin.get();
    
    return 0;
}
