// if1
// Example using the if statement

#include<iostream>

using namespace std;

int  x;

int main()
{
	cout << "Enter a Number: ";
	cin >> x;

	if((x % 2) == 0 )
		cout << x << " is even. " << endl;

	if((x % 2) != 0 )
	{
	    cout << x << " is odd. " << endl;
	}
	
    cin.clear();                               //clear error flag so future cin's will work 
    cin.ignore(1000,'\n');                     //clear buffer - first 1000 chars or to a newline 

	cin.get();
	return 0;

}
