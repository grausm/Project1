//modulo.cpp
//Example of modulo arithmetic and the modulo operator (5)

#include<iostream>

float r;

using namespace std;

int main()
{
    r = 22 % 7;
    
    cout << "22 % 7 = " << r << endl;
    
    cin.clear();                               
    cin.ignore(1000,'\n');                     
    cin.get();
    
    return 0;
}
