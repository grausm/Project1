// AddressOf.cpp 
// Example of the 'Address of' Operator &

#include<iostream>

using namespace std;

int main()
{
    int x = 44;
    
    cout << " Value of x:   " << x << endl;
    cout << " Address of x: " << &x << endl;
    
    cin.clear();                               
    cin.ignore(1000,'\n');                     
    cin.get();
 
    return 0;   
}
