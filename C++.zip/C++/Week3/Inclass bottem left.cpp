#include<iostream>

using namespace std;

int main()
{
	for(int x = 0; x < 3; x++)			
	{
        for(int y = 3; y > x; y--)
        cout <<" ";
        {
            if (y < 4 && y > 5)
            cout << " ";
            else
            {
                cout << "*";
            }
        }
		cout << endl;
	}
	
	cin.get();
	
	return 0;

}
