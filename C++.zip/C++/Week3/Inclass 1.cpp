// Program For1
// Example using a for-statement

// for-statement consists of 3 parts...
// 1-The Loop Variable
// 2-The Terminating Condition
// 3-The Expression that Updates the Loop Variable

#include<iostream>

using namespace std;

int main()
{
	for(int x = 0; x < 10; x++)			
	{
        for(int y = 0; y < 20; y++ )
        {
            if (y < x )
            cout << " ";
            else
            {
                cout << "*";
                if (y = 10)
                cout << " ";
            }
        }
		cout << endl;
	}
	
	cin.get();
	
	return 0;

}
