// floatingPt.cpp
// a represents a number with 23 digits to the left of the decimal
// by adding 1 to the 23rd digit to the number.
// Type float can represent only the first 6 or 7 in the number.
// Changing the 23rd digit will have no effect on the value.   

#include<iostream>

using namespace std;

int main()
{
    float a = 2.34E+22f;
    float b = a + 1.0f;
    
    cout << "a = " << a << endl;
    cout << "b = " << a << endl;
    cout << "b - a = " << b - a << endl;
    
    cin.clear();                               
    cin.ignore(1000,'\n');                     
    cin.get();
    
    return 0;
}
