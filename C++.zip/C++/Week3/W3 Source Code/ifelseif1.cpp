// ifelseif1.cpp 
// An example of the WRONG way to use an if/else if statement

#include<iostream>
using namespace std;

int main()
{
	int testScore;
	char grade;
	
	cout << "An Example of Using WRONG if/else logic." << endl;
	cout << "(can you explain why it is wrong?)" << endl << endl;

	cout << "Enter your numeric test score: ";
	cin  >> testScore;

	if(testScore <= 100)
		grade = 'A';
	else if (testScore < 90)
		grade = 'B';
	else if (testScore < 80)
		grade = 'C';
	else if (testScore < 70)
		grade = 'D';
	else if (testScore < 60)
		grade = 'F';

	cout << "Your grade is " << grade << endl;

	cout << "Press Enter to Exit...";
	
    cin.clear();                               
    cin.ignore(1000,'\n');                     
    cin.get();
	return 0;
}
