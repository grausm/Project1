
// if1.cpp
// Example using the if statement

#include<iostream>

using namespace std;

int  x;

int main()
{
	cout << "Enter a Number: ";
	cin >> x;

	if((x % 2) == 0 )
		cout << x << " is even. " << endl;

	if((x % 2) != 0 )
	{
	    cout << x << " is odd. " << endl;
	}
	
	cout << "Press Enter to Exit...";
	
    cin.clear();                               
    cin.ignore(1000,'\n');                     
    cin.get();
    
	return 0;

}
