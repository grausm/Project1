// Program for2
// Example using nexting for statements

// for-statement consists of 3 parts...
// 1-The Loop Variable
// 2-The Terminating Condition
// 3-The Expression that Updates the Loop Variable

#include<iostream>

using namespace std;

int main()
{
	for(int x = 0; x < 10 ; x++)			
	{
		cout << x << ' ';
		for(int y = 3; y < 6; y++)
		{
			cout << y << " - ";
		}
		cout << endl;
	}
	
	cin.get();
	
	return 0;

}
