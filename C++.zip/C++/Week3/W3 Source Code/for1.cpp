// Program For1
// Example using a for-statement

// for-statement consists of 3 parts...
// 1-The Loop Variable
// 2-The Terminating Condition
// 3-The Expression that Updates the Loop Variable

#include<iostream>

using namespace std;

int main()
{
	for(int x = 0; x < 6; x++)			
	{
        for(int y = 5; y < x; y++)
        {
            cout << "*";
        }
		cout << "*" << endl;
	}
	
	cin.get();
	
	return 0;

}
